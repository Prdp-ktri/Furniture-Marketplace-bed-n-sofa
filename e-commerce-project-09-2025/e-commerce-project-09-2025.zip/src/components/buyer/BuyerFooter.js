import React from "react";

function BuyerFooter() {
  return <div></div>;
}

export default BuyerFooter;
