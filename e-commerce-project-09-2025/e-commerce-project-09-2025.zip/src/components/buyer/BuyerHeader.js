import React from "react";

function BuyerHeader() {
  return <div></div>;
}

export default BuyerHeader;
