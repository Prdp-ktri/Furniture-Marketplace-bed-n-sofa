import React from 'react'

function AdminDashboard() {
  return (
    <div>
      
    </div>
  )
}

export default AdminDashboard
