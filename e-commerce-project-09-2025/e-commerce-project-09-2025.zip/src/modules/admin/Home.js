import React from 'react'
import Dashboard from './AdminDashboard'

function Home() {
  return (
    <div>
      <Dashboard/>
    </div>
  )
}

export default Home
