import React from "react";

function BuyerDashboard() {
  return <div></div>;
}

export default BuyerDashboard;
