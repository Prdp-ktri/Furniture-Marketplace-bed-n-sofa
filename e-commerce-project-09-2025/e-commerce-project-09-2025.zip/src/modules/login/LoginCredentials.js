import React from "react";

function LoginCredentials() {
  return <div></div>;
}

export default LoginCredentials;
