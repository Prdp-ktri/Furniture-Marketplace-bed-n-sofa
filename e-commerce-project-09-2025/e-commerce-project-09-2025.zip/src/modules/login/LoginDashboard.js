import React from "react";

function LoginDashboard() {
  return <div></div>;
}

export default LoginDashboard;
