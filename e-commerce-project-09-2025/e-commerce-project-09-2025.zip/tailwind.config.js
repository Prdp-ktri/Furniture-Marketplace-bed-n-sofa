module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}", // CRA scans your React files
    "./public/index.html",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
